<?php
global $listing_id;

$listing_id = ( is_null( $listing_id ) ) ? get_the_ID() : $listing_id;
?>
<div class="post-content">
	<?php
	echo wp_kses_post( wpautop( get_the_content( null, null, $listing_id ) ) );
	?>
</div>
