<?php
$view_type = apply_filters( 'motors_vl_get_nuxy_mod', 'grid', 'listing_view_type' );
$filter    = apply_filters( 'stm_listings_filter_func', null, true );

if ( ! empty( $_GET['view_type'] ) && in_array( $_GET['view_type'], array( 'grid', 'list' ), true ) ) {
	$view_type = sanitize_text_field( $_GET['view_type'] );
}

$ppp             = ${'ppp_on_' . $view_type};
$custom_img_size = ${$view_type . '_thumb_img_size'};
$custom_img_size = ( ! empty( $custom_img_size ) && ( in_array( $custom_img_size, get_intermediate_image_sizes() ) || 'full' === $custom_img_size ) ) ? $custom_img_size : null;

if ( ! isset( $post_type ) || empty( $post_type ) ) {
	$post_type = 'listings';
}
?>
<?php
do_action(
	'stm_listings_load_template',
	'classified/filter/actions',
	array(
		'filter'    => $filter,
		'elementor' => true,
	)
);
?>
<div class="motors-elementor-inventory-search-results" id="listings-result" data-custom-img-size="<?php echo ! empty( $custom_img_size ) ? esc_attr( $custom_img_size ) : ''; ?>">
	<?php
	do_action(
		'stm_listings_load_results',
		array(
			'posts_per_page'  => $ppp,
			'post_type'       => $post_type,
			'custom_img_size' => $custom_img_size,
		)
	);

	wp_reset_query(); //phpcs:ignore
	?>
</div>
