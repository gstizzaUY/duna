<?php
add_filter( 'mlt_conf_inventory_general', 'mlt_conf_inventory_general', 10, 2 );

function mlt_conf_inventory_general( array $fields, $slug ) {
	return array_merge(
		$fields,
		array(
			$slug . '_inventory_settings_title'        => array(
				'type'       => 'group_title',
				'label'      => esc_html__( 'General', 'motors_listing_types' ),
				'submenu'    => esc_html__( 'Inventory Settings', 'motors_listing_types' ),
				'dependency' => array(
					'key'   => $slug . '_inventory_custom_settings',
					'value' => 'not_empty',
				),
				'group'      => 'started',
			),
			$slug . '_listing_directory_title_default' => array(
				'label'        => esc_html__( 'Default Title', 'motors_listing_types' ),
				'type'         => 'text',
				'value'        => '',
				'submenu'      => esc_html__( 'Inventory Settings', 'motors_listing_types' ),
				'dependency'   => array(
					array(
						'key'   => $slug . '_inventory_custom_settings',
						'value' => 'not_empty',
					),
					array(
						'key'     => 'multilisting_current_motors_layout',
						'value'   => 'aircrafts||car_dealer_two||car_magazine||listing||listing_two||listing_three||listing_four||listing_five||listing_six||listing_one_elementor||listing_two_elementor||listing_three_elementor||listing_four_elementor||listing_five_elementor||motorcycle',
						'section' => 'listing_types',
					),
				),
				'dependencies' => '&&',
			),
			$slug . '_classic_listing_title'           => array(
				'label'        => esc_html__( 'Listing Archive "Title Box" Title', 'motors_listing_types' ),
				'type'         => 'text',
				'submenu'      => esc_html__( 'Inventory Settings', 'motors_listing_types' ),
				'value'        => '',
				'dependencies' => '&&',
				'dependency'   => array(
					array(
						'key'   => $slug . '_inventory_custom_settings',
						'value' => 'not_empty',
					),
					array(
						'key'     => 'multilisting_current_motors_layout',
						'value'   => 'aircrafts||boats||car_dealer_two||car_magazine||listing||listing_two||listing_three||listing_four||listing_five||listing_six||listing_one_elementor||listing_two_elementor||listing_three_elementor||listing_four_elementor||listing_five_elementor||motorcycle',
						'section' => 'listing_types',
					),
				),
				'dependencies' => '&&',
			),
			$slug . '_show_sold_listings'              => array(
				'label'       => esc_html__( 'Sold Listings', 'motors_listing_types' ),
				'description' => 'Display sold listings in the Classic and Modern filters',
				'type'        => 'checkbox',
				'value'       => false,
				'submenu'     => esc_html__( 'Inventory Settings', 'motors_listing_types' ),
				'dependency'  => array(
					'key'   => $slug . '_inventory_custom_settings',
					'value' => 'not_empty',
				),
			),
			$slug . '_sold_badge_bg_color'             => array(
				'label'        => esc_html__( 'Sold Badge Background Color', 'motors_listing_types' ),
				'type'         => 'color',
				'mode'         => 'background-color',
				'value'        => '#fc4e4e',
				'submenu'      => esc_html__( 'Inventory Settings', 'motors_listing_types' ),
				'dependency'   => array(
					array(
						'key'   => $slug . '_show_sold_listings',
						'value' => 'not_empty',
					),
					array(
						'key'   => $slug . '_inventory_custom_settings',
						'value' => 'not_empty',
					),
				),
				'dependencies' => '&&',
				'group'        => 'ended',
			),
		),
	);
}
