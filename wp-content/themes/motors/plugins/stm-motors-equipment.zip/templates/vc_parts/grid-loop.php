<?php
$gallery_hover_interaction = apply_filters( 'motors_vl_get_nuxy_mod', false, 'gallery_hover_interaction' );
$dynamic_class_photo       = 'stm-car-photos-' . get_the_ID() . '-' . wp_rand( 1, 99999 );
$dynamic_class_video       = 'stm-car-videos-' . get_the_ID() . '-' . wp_rand( 1, 99999 );
$image_size                = 'stm-img-350-205';
$show_compare              = apply_filters( 'motors_vl_get_nuxy_mod', false, 'show_listing_compare' );
$car_media                 = apply_filters( 'stm_get_car_medias', array(), get_the_id() );
$page_id                   = get_queried_object_id();
$is_inventory              = intval( apply_filters( 'stm_me_get_nuxy_mod', 0, 'listing_archive' ) ) === $page_id;
$img_attrs                 = array(
	'sizes'   => '(max-width: 767px) 100vw, (max-width: 991px) 50vw, (max-width: 1190px) 33vw, 350px',
	'class'   => 'img-responsive',
	'alt'     => get_the_title(),
	'loading' => 'lazy',
);
?>
<div class="dp-in">
	<div class="listing-car-item">
		<div class="listing-car-item-inner">
			<a href="<?php the_permalink(); ?>" class="rmv_txt_drctn" title="
			<?php
			esc_attr_e( 'Watch full information about', 'stm_motors_equipment' );
			echo esc_attr( ' ' . get_the_title() );
			?>
			">
				<?php if ( has_post_thumbnail() ) : ?>
					<div class="text-center">
						<div class="image dp-in">

							<?php
							$thumbs = apply_filters( 'stm_get_hoverable_thumbs', array(), get_the_ID(), $image_size );
							if ( true === $gallery_hover_interaction && count( $thumbs['gallery'] ) > 1 ) {
								$array_keys    = array_keys( $thumbs['gallery'] );
								$last_item_key = array_pop( $array_keys );
								?>
								<div class="interactive-hoverable">
									<!-- "interactive-hoverable" -->
									<?php
									do_action( 'stm_listing_image_hover_gallery', $thumbs, $image_size, $img_attrs, false );
									stm_equipment_load_template( 'vc_parts/badge' );
									?>
								</div>
								<?php
							} else {
								$img    = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $image_size );
								$img_2x = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'stm-img-796-466' );
								?>
								<img src="<?php echo esc_url( $img[0] ); ?>" data-retina="<?php echo esc_url( $img_2x[0] ); ?>" class="img-responsive" alt="<?php the_title(); ?>">
								<?php
								stm_equipment_load_template( 'vc_parts/badge' );
							}
							?>

							<div class="stm-car-medias">
								<?php if ( ! empty( $car_media['car_photos_count'] ) ) : ?>
									<div class="stm-listing-photos-unit stm-car-photos-<?php echo esc_attr( get_the_ID() ); ?> <?php echo esc_attr( $dynamic_class_photo ); ?>">
										<i class="stm-service-icon-photo"></i>
										<span><?php echo esc_html( $car_media['car_photos_count'] ); ?></span>
									</div>

									<script>
										jQuery(document).ready(function(){
											jQuery(".<?php echo esc_attr( $dynamic_class_photo ); ?>").on('click', function(e) {
												e.preventDefault();
												jQuery(this).lightGallery({
													dynamic: true,
													dynamicEl: [
														<?php foreach ( $car_media['car_photos'] as $car_photo ) : ?>
														{
															src  : "<?php echo esc_url( $car_photo ); ?>",
															thumb: "<?php echo esc_url( $car_photo ); ?>",
														},
														<?php endforeach; ?>
													],
													download: false,
													mode: 'lg-fade',
												})
											});
										});

									</script>
								<?php endif; ?>
								<?php if ( ! empty( $car_media['car_videos_count'] ) ) : ?>
									<div class="stm-listing-videos-unit stm-car-videos-<?php echo esc_attr( get_the_ID() ); ?> <?php echo esc_attr( $dynamic_class_video ); ?>">
										<i class="fas fa-film"></i>
										<span><?php echo esc_html( $car_media['car_videos_count'] ); ?></span>
									</div>

									<script>
										jQuery(document).ready(function(){

											jQuery(".<?php echo esc_attr( $dynamic_class_video ); ?>").on('click', function(e) {
												e.preventDefault();

												jQuery(this).lightGallery({
													dynamic: true,
													dynamicEl: [
														<?php foreach ( $car_media['car_videos'] as $car_video ) : ?>
														{
															src  : "<?php echo esc_url( $car_video ); ?>"
														},
														<?php endforeach; ?>
													],
													download: false,
													mode: 'lg-fade',
												})
											}); //click
										}); //ready

									</script>
								<?php endif; ?>
							</div>

							<?php
							$price      = get_post_meta( get_the_id(), 'price', true );
							$sale_price = get_post_meta( get_the_id(), 'sale_price', true );

							$rent_price      = get_post_meta( get_the_id(), 'rent_price', true );
							$rent_sale_price = get_post_meta( get_the_id(), 'rent_sale_price', true );

							$price_label = esc_html__( 'Sale price', 'stm_motors_equipment' );
							$price       = ( ! empty( $sale_price ) ) ? $sale_price : $price;

							if ( ! empty( $_GET['listing-type'] ) && 'for-rent' === $_GET['listing-type'] ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
								$price_label = esc_html__( 'Rent price', 'stm_motors_equipment' );
								$price       = $rent_price;

								if ( ! empty( $rent_sale_price ) ) {
									$price_label = $rent_price;
									$price       = $rent_sale_price;
								}
							}
							$car_price_form_label = get_post_meta( get_the_ID(), 'car_price_form_label', true );

							?>
							<?php if ( ! empty( $car_price_form_label ) ) : ?>
							<div class="price ">
								<?php if ( $is_inventory ) : ?>
									<div class="sale-price heading-font archive_request_price" data-toggle="modal" data-target="#get-car-price" data-title="<?php echo esc_attr( get_the_title( get_the_ID() ) ); ?>" data-id="<?php echo esc_attr( get_the_ID() ); ?>"><?php echo esc_html( $car_price_form_label ); ?></div>
								<?php else : ?>
									<div class="sale-price heading-font" data-title="<?php echo esc_attr( get_the_title( get_the_ID() ) ); ?>" data-id="<?php echo esc_attr( get_the_ID() ); ?>"><?php echo esc_html( $car_price_form_label ); ?></div>
								<?php endif; ?>
							</div>
							<?php else : ?>
								<div class="price">
									<div class="title-price heading-font">
										<?php echo esc_html( $price_label ); ?>
									</div>
									<div class="sale-price heading-font">
										<?php echo esc_html( apply_filters( 'stm_filter_price_view', '', $price ) ); ?>
									</div>
								</div>
							<?php endif; ?>
							<!--Compare-->
							<?php if ( ! empty( $show_compare ) && $show_compare ) : ?>
								<div class="stm-listing-compare stm-compare-directory-new"
									data-id="<?php echo esc_attr( get_the_id() ); ?>"
									data-post-type="<?php echo esc_attr( get_post_type( get_the_ID() ) ); ?>"
									data-title="<?php echo wp_kses_post( apply_filters( 'stm_generate_title_from_slugs', get_the_title( get_the_ID() ), get_the_ID(), false ) ); ?>"
									data-toggle="tooltip" data-placement="right" title="<?php esc_attr_e( 'Add to compare', 'stm_motors_equipment' ); ?>"
								>
									<i class="stm-service-icon-compare-new"></i><?php echo esc_html__( 'Compare', 'stm_motors_equipment' ); ?>
								</div>
							<?php endif; ?>
						</div>
					</div>
				<?php endif; ?>
				<div class="listing-car-item-meta">
					<div class="car-meta-top heading-font clearfix">
						<?php
						$subtitle  = '';
						$body      = wp_get_post_terms( get_the_ID(), 'body', array( 'fields' => 'names' ) );
						$subtitle .= ( ! is_wp_error( $body ) ) ? '<span>' . $body[0] . '</span>' : '';
						?>
						<div class="car-subtitle heading-font">
							<?php echo wp_kses_post( $subtitle ); ?>
						</div>
						<div class="car-title">
							<?php echo wp_kses_post( apply_filters( 'stm_generate_title_from_slugs', get_the_title( get_the_ID() ), get_the_ID(), true ) ); ?>
						</div>
					</div>
					<div class="car-meta-bottom">
						<?php
						$stock = get_post_meta( get_the_ID(), 'stock_number', true );
						$hours = get_post_meta( get_the_ID(), 'hours', true );

						$hours = ( ! empty( $hours ) ) ? $hours : 0;
						?>
						<div class="stock-wrap">
							<?php echo '<span>' . esc_html__( 'Stock#', 'stm_motors_equipment' ) . '</span> ' . esc_html( $stock ); ?>
						</div>
						<div class="hours-wrap">
							<?php echo '<span>' . esc_html__( 'Hours:', 'stm_motors_equipment' ) . '</span> ' . esc_html( $hours ); ?>
						</div>
					</div>
				</div>
			</a>
		</div>
	</div>
</div>
