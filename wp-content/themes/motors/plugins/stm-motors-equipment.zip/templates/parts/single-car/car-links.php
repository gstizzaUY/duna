<?php
$id                 = get_the_ID();
$history_link       = get_post_meta( $id, 'history_link', true );
$show_share         = apply_filters( 'motors_vl_get_nuxy_mod', false, 'show_share' );
$show_test_drive    = apply_filters( 'motors_vl_get_nuxy_mod', false, 'show_test_drive' );
$stm_car_link_quote = apply_filters( 'motors_vl_get_nuxy_mod', '#1471332454395-0e51ff9f-8682', 'stm_car_link_quote' );
$show_quote_phone   = apply_filters( 'motors_vl_get_nuxy_mod', false, 'show_quote_phone' );
$car_price_form     = get_post_meta( get_the_ID(), 'car_price_form', true );
$show_trade_in      = apply_filters( 'motors_vl_get_nuxy_mod', false, 'show_trade_in' );
$show_calculator    = apply_filters( 'motors_vl_get_nuxy_mod', false, 'show_calculator' );
$show_report        = apply_filters( 'motors_vl_get_nuxy_mod', false, 'show_history' );


$links = array();

if ( ! empty( $stm_car_link_quote ) ) {
	$links['stm-moto-icon-chat'] = array(
		'link'   => $stm_car_link_quote,
		'target' => '_self',
		'text'   => esc_html__( 'Request a quote', 'stm_motors_equipment' ),
	);
}

if ( $show_test_drive ) {
	$links['stm-moto-icon-helm'] = array(
		'link'  => '#test-drive',
		'modal' => 'data-toggle="modal" data-target="#test-drive"',
		'text'  => esc_html__( 'Schedule test drive', 'stm_motors_equipment' ),
	);
}

if ( $show_quote_phone && ! empty( $car_price_form ) && 'on' === $car_price_form ) {
	$links['stm-moto-icon-phone-chat'] = array(
		'link'  => '#get-a-call',
		'modal' => 'data-toggle="modal" data-target="#get-car-price"',
		'text'  => esc_html__( 'Quote by Phone', 'stm_motors_equipment' ),
	);
}

if ( $show_trade_in ) {
	$links['stm-moto-icon-trade'] = array(
		'link'  => '#trade-in',
		'modal' => 'data-toggle="modal" data-target="#trade-in"',
		'text'  => esc_html__( 'Trade In', 'stm_motors_equipment' ),
	);
}

if ( $show_calculator ) {
	$links['stm-moto-icon-cash'] = array(
		'link'  => '#calc',
		'modal' => 'data-toggle="modal" data-target="#get-car-calculator"',
		'text'  => esc_html__( 'Сalculate Payment', 'stm_motors_equipment' ),
	);
}

if ( $show_share ) {
	$links['stm-moto-icon-share'] = array(
		'link' => '#calculator',
		'text' => esc_html__( 'Share this', 'stm_motors_equipment' ),
	);
}

if ( ! empty( $history_link ) && $show_report ) {
	$links['stm-moto-icon-report'] = array(
		'link' => esc_url( $history_link ),
		'text' => esc_html__( 'History report', 'stm_motors_equipment' ),
	);
}

?>


<div class="stm-single-car-links">
	<?php foreach ( $links as $icon => $link ) : ?>
		<?php
		$target = '_blank';
		if ( ! empty( $link['target'] ) ) {
			$target = $link['target'];
		}
		?>
		<div class="stm-single-car-link unit-<?php echo esc_attr( $icon ); ?> heading-font">
			<a href="<?php echo esc_url( $link['link'] ); ?>" target="<?php echo esc_attr( $target ); ?>"
				<?php
				if ( ! empty( $link['modal'] ) ) {
					echo $link['modal']; //phpcs:ignore
				}
				?>
				<?php
				if ( 'stm-moto-icon-share' === $icon ) {
					echo 'class="stm-share"';
				}
				?>
				>
				<i class="<?php echo esc_attr( $icon ); ?>"></i>
				<?php echo esc_html( $link['text'] ); ?>
			</a>
			<?php if ( 'stm-moto-icon-share' === $icon && function_exists( 'ADDTOANY_SHARE_SAVE_KIT' ) && ! get_post_meta( get_the_ID(), 'sharing_disabled', true ) ) : ?>
				<div class="stm-a2a-popup">
					<?php echo do_shortcode( '[addtoany url="' . get_the_permalink( get_the_ID() ) . '" title="' . get_the_title( get_the_ID() ) . '"]' ); ?>
				</div>
			<?php endif; ?>
		</div>
	<?php endforeach; ?>
</div>
