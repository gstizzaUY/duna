<?php
$car_option_posts = $__vars['query_posts'];

if ( $car_option_posts->have_posts() ) :
	?>
	<div class="stm_rental_options_archive">
		<?php
		while ( $car_option_posts->have_posts() ) :
			$car_option_posts->the_post();
			stm_car_rental_load_template( 'shop/loop/option', array( 'invisId' => $__vars['invisId'] ) );
		endwhile;
		?>
		<script>
			jQuery(document).ready(function () {
				var $ = jQuery;
				$('.stm-manage-stock-yes a').on('click', function (e) {
					e.preventDefault();
					e.stopPropagation();
					var stmHref = $(this).attr('href');
					var quantityValue = $(this).closest('.meta').find('.qty').val();
					var quantity = '&quantity=' + quantityValue;
					stmHref += quantity;
					window.location.href = stmHref;
				});
			});
		</script>
	</div>

	<?php
endif;
wp_reset_postdata();
